package org.apache.commons.math.linear;


public class DefaultRealMatrixPreservingVisitor implements org.apache.commons.math.linear.RealMatrixPreservingVisitor {
	public void start(int rows, int columns, int startRow, int endRow, int startColumn, int endColumn) {
	}

	public void visit(int row, int column, double value) throws org.apache.commons.math.linear.MatrixVisitorException {
	}

	public double end() {
		return 0;
	}
}

